package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
  
public class PayrollServicesImpl implements PayrollServices{
	
	private AssociateDAO associateDAO;

	@Override
	public int acceptAssociateDetails(int yearlyInvestmentUnder80C, String fisrtName, String lastName,
			String department, String designation, String pancard, String emaiID, int basicSalary, int epf,
			int companyPF, int accountNumber, String bankName, String ifscCode) {
		return 0;
	}

	@Override
	public int calculateNetSalary(int associateID) {
		return 0;
	}

	@Override
	public Associate getAssociateDetails(int associateID) {
		return null;
	}

	@Override
	public List<Associate> getAllAssociateDetails() {
		return null;
	}



	

	
}
