package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestLifecycle {
//settor inj singleton apll context
	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("cg.xml");
IGreet g1=(IGreet)ctx.getBean("obj1");
//System.out.println("Observe LifeCycle");
System.out.println(g1.greeMe());

	}

}
