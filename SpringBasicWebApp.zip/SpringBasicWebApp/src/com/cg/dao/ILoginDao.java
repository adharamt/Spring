package com.cg.dao;
import java.util.ArrayList;

import com.cg.dto.Login;
import com.cg.dto.RegisterDto;
public interface ILoginDao {
public boolean isUserExist(String usn);
public Login validateUser(Login login);
public RegisterDto insertUserDetails(RegisterDto userDetails);
public ArrayList<RegisterDto>getAllUserDetails();
public RegisterDto deleteUsers(String usn);
public RegisterDto updateUsers(String usn);
}
