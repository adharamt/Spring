package com.cg.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class QueryMaster {
	@Id
private int query_Id;
private String technology;
private String question;
private String raisedBy;
private String solution;
private String answeredBy;
public QueryMaster() {
	super();
	// TODO Auto-generated constructor stub
}

public int getQuery_Id() {
	return query_Id;
}
public void setQuery_Id(int query_Id) {
	this.query_Id = query_Id;
}
public String getTechnology() {
	return technology;
}
public void setTechnology(String technology) {
	this.technology = technology;
}
public String getQuestion() {
	return question;
}
public void setQuestion(String question) {
	this.question = question;
}
public String getRaisedBy() {
	return raisedBy;
}
public void setRaisedBy(String raisedBy) {
	this.raisedBy = raisedBy;
}
public String getSolution() {
	return solution;
}
public void setSolution(String solution) {
	this.solution = solution;
}
public String getAnsweredBy() {
	return answeredBy;
}
public void setAnsweredBy(String answeredBy) {
	this.answeredBy = answeredBy;
}
@Override
public String toString() {
	return "QueryMaster [query_Id=" + query_Id + ", technology=" + technology + ", question=" + question + ", raisedBy="
			+ raisedBy + ", solution=" + solution + ", answeredBy=" + answeredBy + "]";
}


}
