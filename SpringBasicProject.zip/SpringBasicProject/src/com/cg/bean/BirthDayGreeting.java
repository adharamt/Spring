package com.cg.bean;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class BirthDayGreeting implements IGreet,BeanNameAware,BeanFactoryAware,DisposableBean,InitializingBean{
String firstName;


	public BirthDayGreeting() {
	super();
	System.out.println("In ctor");
}

	public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
	System.out.println("set first name called");
}

	@Override
	public String greeMe() {
	return "Happy Birthday "+ firstName;
		
	}

	public BirthDayGreeting(String firstName) {
		super();
		this.firstName = firstName;
	}

	@Override
	public void setBeanName(String beanName) {//gives bean name inside of cg.xml
		System.out.println("In setBeanName() called  "+beanName);
		
	}

	@Override
	public void setBeanFactory(BeanFactory bf) throws BeansException {
		System.out.println("---In setbeanfactoryaware()---"+ bf.toString());
		
	}

	@Override
	public String toString() {
		return "BirthDayGreeting [firstName=" + firstName + "]";
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("this is called afyr first name set");
		
	}

	@Override
	public void destroy() throws Exception {//disposable
		System.out.println("destroy is called ");//when appl exit then only this called 	
		
	}
public void cgInit() {//want to call when cg is initialize
System.out.println("this is custom init");	
}

public void cgdestory() {
System.out.println("this is custom cg destory");	
}
}

