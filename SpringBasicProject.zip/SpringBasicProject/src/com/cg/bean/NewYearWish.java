package com.cg.bean;

public class NewYearWish implements IGreet {
	String firstName;
	int year;

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
		System.out.println("set year called");
	}

	public NewYearWish() {
		super();
		System.out.println("In ctor");
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
		System.out.println("set first name called");
	}

	@Override
	public String greeMe() {
		return "Happy New Year "+ year+" "+ firstName;

	}

	public NewYearWish(String firstName, int year) {//for ctor injection
		super();
		this.firstName = firstName;
		this.year = year;
	}

}
