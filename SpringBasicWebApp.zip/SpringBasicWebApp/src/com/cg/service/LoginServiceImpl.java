package com.cg.service;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ILoginDao;
import com.cg.dto.Login;
import com.cg.dto.RegisterDto;
@Service("loginSer")
public class LoginServiceImpl implements ILoginService{
	@Autowired
	ILoginDao loginDao=null;
	public ILoginDao getLoginDao() {
		return loginDao;
	}

	public void setLoginDao(ILoginDao loginDao) {
		this.loginDao = loginDao;
	}

	@Override
	public boolean isUserExist(String usn) {
		return loginDao.isUserExist(usn);
	}

	@Override
	public Login validateUser(Login login) {
		Login dbUser=loginDao.validateUser(login);
		if((login.getUsername().equalsIgnoreCase(dbUser.getUsername()))&&login.getPassword().equalsIgnoreCase(dbUser.getPassword()))
		{

			return login;
		}
		else
		{
			return null;	
		}
	}

	@Override
	public RegisterDto insertUserDetails(RegisterDto userDetails) {

		return loginDao.insertUserDetails(userDetails);
	}

	@Override
	public ArrayList<RegisterDto> getAllUserDetails() {
		
		return loginDao.getAllUserDetails();
	}

	@Override
	public RegisterDto deleteUsers(String usn) {
		
		return loginDao.deleteUsers(usn);
	}



}
