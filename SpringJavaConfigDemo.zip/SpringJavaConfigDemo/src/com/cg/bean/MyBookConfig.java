package com.cg.bean;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration// java based configuration
public class MyBookConfig {
@Bean
public Author author() {
	return new Author("Kanitkar","Nagpur");
}

@Bean(initMethod="setUp",destroyMethod="cleanUp")
@Scope("prototype")
public Book book() {
	Book book=new Book();
	book.setYear("1995");
	book.setIsbn("Kj77756");
	book.setAuthor(author());
	return book;
}
}
