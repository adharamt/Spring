package com.cg.bean;

import org.springframework.context.*;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestSpringAppContentContainerDemo {
public static void main(String[] args) {
	ApplicationContext ctx=new ClassPathXmlApplicationContext("cg.xml");// usimg prototype
	
	System.out.println("---spring container was initialized--");
	System.out.println("---bday wish--");
	IGreet g1=(IGreet)ctx.getBean("obj1");
	System.out.println(g1.greeMe());
	System.out.println(g1.hashCode());
	//dependency injection using setter injection
	
    System.out.println("---new year wish--");
	IGreet g2=(IGreet)ctx.getBean("obj2");
	System.out.println(g2.greeMe());
	System.out.println(g2.hashCode());	
	
	
	
	IGreet g3=(IGreet)ctx.getBean("obj1");
	System.out.println(g3.greeMe());
	System.out.println(g3.hashCode());
	
	
	IGreet g4=(IGreet)ctx.getBean("obj1");
	System.out.println(g4.greeMe());
	System.out.println(g4.hashCode());
	
	//ctor injection
	System.out.println("ctor injection");
	IGreet g5=(IGreet)ctx.getBean("obj3");
	System.out.println(g5.greeMe());
	System.out.println(g5.hashCode());
	IGreet g6=(IGreet)ctx.getBean("obj4");
	System.out.println(g6.greeMe());
	System.out.println(g6.hashCode());
}
}
