package com.cg.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {
@Id
private int productId;
private int  userId, price,category,soldQuantities,stock,discount;
private String productName,description,type,views;
public Product() {
	super();
	}
public Product(int productId, int userId, int price, int category, int soldQuantities, int stock, int discount,
		String productName, String description, String type, String views) {
	super();
	this.productId = productId;
	this.userId = userId;
	this.price = price;
	this.category = category;
	this.soldQuantities = soldQuantities;
	this.stock = stock;
	this.discount = discount;
	this.productName = productName;
	this.description = description;
	this.type = type;
	this.views = views;
}
public int getProductId() {
	return productId;
}
public void setProductId(int productId) {
	this.productId = productId;
}
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public int getCategory() {
	return category;
}
public void setCategory(int category) {
	this.category = category;
}
public int getSoldQuantities() {
	return soldQuantities;
}
public void setSoldQuantities(int soldQuantities) {
	this.soldQuantities = soldQuantities;
}
public int getStock() {
	return stock;
}
public void setStock(int stock) {
	this.stock = stock;
}
public int getDiscount() {
	return discount;
}
public void setDiscount(int discount) {
	this.discount = discount;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getViews() {
	return views;
}
public void setViews(String views) {
	this.views = views;
}
@Override
public String toString() {
	return "Product [productId=" + productId + ", userId=" + userId + ", price=" + price + ", category=" + category
			+ ", soldQuantities=" + soldQuantities + ", stock=" + stock + ", discount=" + discount + ", productName="
			+ productName + ", description=" + description + ", type=" + type + ", views=" + views + "]";
}

}
