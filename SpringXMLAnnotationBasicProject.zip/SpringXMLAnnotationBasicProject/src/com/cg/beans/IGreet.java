package com.cg.beans;

public interface IGreet {
public String greeMe();
}
