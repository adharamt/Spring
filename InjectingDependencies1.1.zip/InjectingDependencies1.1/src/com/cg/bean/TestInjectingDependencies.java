package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestInjectingDependencies {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("cgbeans.xml");
		System.out.println("---Employee Details---");
		System.out.println("-----------------------");
		Employee emp=(Employee)ctx.getBean("Emp");
		System.out.println("EmployeeId : "+emp.getEmployeeId());
		System.out.println("Employee Name : "+emp.getEmployeeName());
		System.out.println("Employee Salary : "+emp.getSalary());
		System.out.println("Employee Age : "+emp.getAge());
		System.out.println("Employee BU : "+emp.getBusinessUnit());
		

	}

}
