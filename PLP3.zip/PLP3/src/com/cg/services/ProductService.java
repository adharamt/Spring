package com.cg.services;

import com.cg.bean.Product;

public interface ProductService {
	public Product findProductById(int productId);
}
