package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Session1;
@Repository
@Transactional
public class SessionDAOImpl implements ISessionDAO {
	@PersistenceContext
	EntityManager entityManager= null;
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	@Override
	public List<Session1> displayAllSessions() {
		return entityManager.createQuery("from Session1 h", Session1.class).getResultList();
	}
}


	
	