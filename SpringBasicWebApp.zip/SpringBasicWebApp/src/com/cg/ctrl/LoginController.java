package com.cg.ctrl;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.Login;
import com.cg.dto.RegisterDto;
import com.cg.service.ILoginService;

@Controller
public class LoginController {
	ArrayList<String> cityList=null;
	ArrayList<String> skillSetL=null;
	
	@Autowired
	ILoginService loginSer=null;
	
	
	public ILoginService getLoginSer() {
		return loginSer;
	}
	public void setLoginSer(ILoginService loginSer) {
		this.loginSer = loginSer;
	}
	@RequestMapping(value="ShowLoginPage",method=RequestMethod.GET)
	public String displayLoginPage(Model model) {//string is viewname(login)it will go to login.jsp
		Login lg=new Login();
		//lg.setUsername("Enter your username here");
		model.addAttribute("log",lg);
		model.addAttribute("CompNameObj","Capgemini");//like add fun hash map key n value
		return "Login";
	}
	//**************validate user*********//
	@RequestMapping(value="/ValidateUser",method=RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value="log") 
			@Valid Login lg,BindingResult result,Model model) {
		//@ModelAttribute Login lg//FOR RECEVING DATA FORM LOG OBJ OF LOGIN CLASS
		if(result.hasErrors())
		{
			return "Login";
		}
		else
		
		{
			if(loginSer.isUserExist(lg.getUsername())) {
		Login user=loginSer.validateUser(lg);
		if(user!=null)
		{
			model.addAttribute("unmObj", lg.getUsername());
			return "Sucess";
		}
		else
		{
			return "Failure";	
		}}
			else
			{
				return "redirect:/ShowRegisterPage.obj";
			}
			}
}
	
//**************Show Register Page***********
@RequestMapping(value="/ShowRegisterPage")
public String dispRegPage(Model model)
{
	 cityList=new ArrayList<>();
	cityList.add("Pune");
	cityList.add("Nagpur");
	cityList.add("Mumbai");
	cityList.add("Noida");
	
	
	 skillSetL=new ArrayList<>();
	skillSetL.add("Java");
	skillSetL.add("DotNet");
	skillSetL.add("Oracle");
	skillSetL.add("Html");
	skillSetL.add("BI");
	
	RegisterDto rd=new RegisterDto();
	model.addAttribute("reg",rd);
	model.addAttribute("cList",cityList);
	model.addAttribute("skillList",skillSetL);
	return "Register";
	
}
//***************Inserting details**********
@RequestMapping(value="/InsertUser",method=RequestMethod.POST)
public String addUserDetails(@ModelAttribute(value="reg")
                             @Valid
                             RegisterDto rd,
                             BindingResult result,
                             Model model) {
	if(result.hasErrors()) {
		System.out.println("in error..."+rd);
		model.addAttribute("cList",cityList);
		model.addAttribute("skillList",skillSetL);
		return "Register";
	}
	else
	{
		System.out.println("no error..."+rd);
		RegisterDto rdd=loginSer.insertUserDetails(rd);
		ArrayList<RegisterDto>userList=loginSer.getAllUserDetails();
	model.addAttribute("userListObj",userList);
	return"ListAllUser";
	}
	
}
//*****deleteUser.obj request**********//
@RequestMapping(value="/deleteUser",method=RequestMethod.GET)
public String deleteUser(@RequestParam(value="uid")String unm,Model model)
{
	RegisterDto rd=loginSer.deleteUsers(unm);
	if(rd!=null)
	{
		ArrayList<RegisterDto> userList=loginSer.getAllUserDetails();
		model.addAttribute("userListObj",userList);
		model.addAttribute("MsgObj","Data Deleted");
		return "ListAllUser";
	}
	return "Error";
}
}








