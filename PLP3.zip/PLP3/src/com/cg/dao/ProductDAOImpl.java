package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Product;
@Repository
@Transactional
public class ProductDAOImpl implements ProductDAO {
	@PersistenceContext
	EntityManager entityManager=null;


	public EntityManager getEntityManager() { //setter getter  entityManager
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	@Override
	public Product findProductById(int productId) {

		return entityManager.find(Product.class, productId);
	}

}
