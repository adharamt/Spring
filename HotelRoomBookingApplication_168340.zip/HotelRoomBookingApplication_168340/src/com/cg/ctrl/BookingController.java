package com.cg.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.bean.HotelDetails;

import com.cg.service.IBookingService;

@Controller
public class BookingController {
	@Autowired// dependency injection
	IBookingService iBookingService;

	public IBookingService getiBookingService() {
		return iBookingService;
	}

	public void setiBookingService(IBookingService iBookingService) {
		this.iBookingService = iBookingService;
	}
// to show details page
	@RequestMapping(value="HotelDetailsPage", method=RequestMethod.GET)
	public String displayHotelDetails(ArrayList<HotelDetails> hotels, Model model) {
		hotels= (ArrayList<HotelDetails>) iBookingService.displayAllHotels();
		model.addAttribute(hotels);
		return "HotelDetails";
	}

}


