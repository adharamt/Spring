package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.cg.bean.Country;
import com.cg.dao.ICountryDao;
@Service
public class CountryServiceImpl implements IcountryService {
	@Autowired
	ICountryDao countryDao;
	

	public ICountryDao getCountryDao() {
		return countryDao;
	}

	public void setCountryDao(ICountryDao countryDao) {
		this.countryDao = countryDao;
	}

	@Override
	public List<Country> getAllCountries() {
		return countryDao.getAllCountries();
	}

	@Override
	public void addCountry(Country country) {
	countryDao.addCountry(country);
		
	}

	@Override
	public Country deleteCountry(int id) {
	countryDao.deleteCountry(id);
		return null;
	}

	@Override
	public Country searchCountry(int id) {
	
		return countryDao.searchCountry(id);
	}

}
