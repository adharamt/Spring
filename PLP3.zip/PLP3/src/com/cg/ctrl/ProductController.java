package com.cg.ctrl;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.Product;
import com.cg.services.ProductServices;
@Controller
public class ProductController {
	@Autowired
	ProductServices proSer;


	public ProductServices getProSer() {
		return proSer;
	}
	public void setProSer(ProductServices proSer) {
		this.proSer = proSer;
	}
	@RequestMapping(value="/displayQuery",method=RequestMethod.GET)
	public String displayQuery(Model model) {
		Product product=new Product();
		model.addAttribute("query", product);
		 System.out.println(product); 
		return "Query";
	}
	 @RequestMapping(value="/displayProduct.obj",method=RequestMethod.POST)
	    public String displayProductReport(@RequestParam(value="query") int product,Model model) {
	      
		 Product products=proSer.findProductById(product);
		 System.out.println(products);
	         model.addAttribute("products",products);
	         return "ListAllUser";

	    }
}
