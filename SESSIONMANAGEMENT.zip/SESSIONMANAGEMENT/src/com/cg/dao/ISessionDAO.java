package com.cg.dao;

import java.util.List;

import com.cg.bean.Session1;

public interface ISessionDAO {
	public List<Session1> displayAllSessions();
}
