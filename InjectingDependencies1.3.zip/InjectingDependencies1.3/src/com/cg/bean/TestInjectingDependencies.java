package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestInjectingDependencies {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("cgbeans.xml");
		System.out.println("---------------");	
		SBU sbu=(SBU)ctx.getBean("Emp");
		System.out.println("----Emp Info------");
		System.out.println("code-  "+sbu.getSbuCode()+
				" head-  "+sbu.getSbuHead()+
				"name-  "+sbu.getSbuName()+
				"Employee-  "+sbu.getEmp());

	}

}
