package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Login;
import com.cg.bean.Trainee;


public interface TraineeService {
	public Login validateUser(Login login);
	public Trainee  insertUserDetails(Trainee trainee);
	public ArrayList<Trainee>getAllUserDetails();
	public Trainee deteteUsers(int traineeId);
	public Trainee getTraineeDetails(int traineeId);
}
