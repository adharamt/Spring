package com.cg.dao;

import java.util.List;

import com.cg.bean.Product;

public interface ProductDAO {
	

	Product findProductById(int productId);
}
