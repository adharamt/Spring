package com.cg.ctrl;

import java.util.List;

import javax.enterprise.inject.Model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Country;
import com.cg.service.ICountryService;

import oracle.net.aso.s;

//@CrossOrigin
@RestController
public class CountryController 
{
	@Autowired
	ICountryService service;

	public void setService(ICountryService service) {
		this.service = service;
	}


	public ICountryService getService() {
		return service;
	}

//***********************************************************//
	@RequestMapping(value="/countries/search/{id}",
			method=RequestMethod.GET,
			headers="Accept=application/json")

	public Country getCountry(@PathVariable int id) {
		return service.searchCountry(id);
	}


//**************************************************************//

	@RequestMapping(value="/countries/search/{id}",
			method=RequestMethod.GET,
			headers="Accept=application/json")
	public List<Country> getAllCountries(Model model){
		return service.getAllCountries();
	}

//********************************************************************//

	@RequestMapping(value="/countries/create/{id}/{name}/{popu}",
			produces="application/json",
			method=RequestMethod.POST)
	public List<Country> createCountry(@PathVariable String id,
			@PathVariable String name,
			@PathVariable String popu,
			ModelAndView model
			){
		Country country =new Country();
		country.setCountryId(id);
		country.setCountryName(name);
		country.setPopulation(popu);
		service.addCountry(country);
		return service.getAllCountries();
	}


//****************************************************************//
	@RequestMapping(value="/countries/delete/{id}",
			headers="Accept=application/json",
			method=RequestMethod.DELETE)
	public List<Country> deleteCountry(@PathVariable int id,
			@PathVariable String name,
			@PathVariable String popu,
			ModelAndView model
			){

		service.deleteCountry(id);
		return service.getAllCountries();
	}
}


