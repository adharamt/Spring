package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Login;
import com.cg.bean.Trainee;


@Repository("traineeDao")
@Transactional
public class TraineeDaoImpl implements TraineeDao {
	@PersistenceContext
	 EntityManager entityManager=null;
	 
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Trainee insertUserDetails(Trainee trainee) {			
		entityManager.persist(trainee);		
		entityManager.flush();
		Trainee rd=entityManager.find(Trainee.class,trainee.getTraineeId());
		return rd;
	}

	@Override
	public ArrayList<Trainee> getAllUserDetails() {
		String qry="select reg from Trainee reg";
		TypedQuery tq=entityManager.createQuery(qry,Trainee.class);
		ArrayList<Trainee> uList=(ArrayList<Trainee>) tq.getResultList();
		return uList;
		
	}

	@Override
	public Trainee deleteUsers(int traineeId) {
		Trainee redDto=entityManager.find(Trainee.class,traineeId);
	
		entityManager.remove(redDto);
	
		entityManager.flush();
		return redDto;
	}

	@Override
	public Trainee updateUsers(Trainee trainee) {
		entityManager.find(Trainee.class,trainee.getTraineeId());	
		Trainee re=entityManager.merge(trainee);
		entityManager.flush();
			return re;
	}

	@Override
	public Trainee getTraineeDetails(int traineeId) {
		// TODO Auto-generated method stub
		return entityManager.find(Trainee.class,traineeId);
	}

}
