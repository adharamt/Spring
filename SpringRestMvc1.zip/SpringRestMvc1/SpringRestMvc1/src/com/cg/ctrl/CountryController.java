package com.cg.ctrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Country;
import com.cg.service.IcountryService;

@RestController
public class CountryController {
	@Autowired
	IcountryService service;

	public IcountryService getService() {
		return service;
	}

	public void setService(IcountryService service) {
		this.service = service;
	}
	@RequestMapping(value="/countries/search/{id}",method=RequestMethod.GET,headers="Accept=application/json")
	public Country getCountry(@PathVariable int id) {
		return service.searchCountry(id);
	}
	@RequestMapping(value="/countries",method=RequestMethod.GET,headers="Accept=application/json")
	public List<Country>getAllCountries(Model model) {
		return service.getAllCountries();

	}
	@RequestMapping(value="/countries/create/{id}/{name}/{popu}", produces="applcation/json",method=RequestMethod.POST)
	public List<Country>createCountry(@PathVariable String id,@PathVariable String name,@PathVariable String popu,Model model){


		Country country=new Country();
		country.setCountryId(id);
		country.setCountryName(name);
		country.setPopulation(popu);
		service.addCountry(country);
		return service.getAllCountries();

	}
	@RequestMapping(value="/countries/create/{id}",headers="Accept=application/json",method=RequestMethod.DELETE)
	public List<Country>deleteCountry(@PathVariable int id){
		service.deleteCountry(id);
		return service.getAllCountries();
	}
}
