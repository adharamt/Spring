package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.HotelDetails;


public interface IBookingService {
	 public List<HotelDetails> displayAllHotels();

}
