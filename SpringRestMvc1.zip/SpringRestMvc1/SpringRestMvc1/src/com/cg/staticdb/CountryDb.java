package com.cg.staticdb;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Country;

public class CountryDb {
	private static ArrayList<Country>countryList=new ArrayList<>();
	static {
		countryList.add(new Country("1111","India","543256"));
		countryList.add(new Country("1112","Pak","5432569"));
		countryList.add(new Country("1113","UK","543255"));
		countryList.add(new Country("1114","US","5432561"));
		countryList.add(new Country("1115","China","5432563"));
	}
 public static ArrayList<Country>getCountryList(){
	return countryList;
	 
 }
 public static void setCountryList(List<Country>countryList) {
	 CountryDb.countryList=(ArrayList<Country>)countryList;
 }
}
