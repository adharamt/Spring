package com.cg.payroll.services;


import java.util.HashSet;
import java.util.List;

import com.cg.payroll.beans.Associate;


public interface PayrollServices {
	int acceptAssociateDetails(int yearlyInvestmentUnder80C,String fisrtName, String lastName, String department,String designation, String pancard, String emaiID,int basicSalary, 
			int epf, int companyPF,int accountNumber, String bankName, String ifscCode) ;
	int calculateNetSalary(int associateID);

	Associate getAssociateDetails(int associateID);

	List<Associate>getAllAssociateDetails();


}
