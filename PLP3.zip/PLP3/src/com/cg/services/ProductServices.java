package com.cg.services;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Product;
import com.cg.dao.ProductDAO;

@Service("proSer")
public class ProductServices implements ProductService {
	@Autowired
	ProductDAO proDAO;

	public ProductDAO getProDAO() {
		return proDAO;
	}

	public void setProDAO(ProductDAO proDAO) {
		this.proDAO = proDAO;
	}
	
	
	@Override
	public Product findProductById(int productId) {
		return  proDAO.findProductById(productId);
	}
}
