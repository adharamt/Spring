

package com.cg.bean;

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {
    @Bean
public ArrayList<Address> getAddList(){
    Address ad1=new Address();
    ad1.setCity("mumbai");
    ad1.setState("MH");
    ad1.setZipcode(8762);
    
    Address ad2=new Address();
    ad2.setCity("Aagra");
    ad2.setState("UP");
    ad2.setZipcode(876265);
    ArrayList<Address>adList=new ArrayList<Address>();
    adList.add(ad1);
    adList.add(ad2);
    return adList;
}
}

