package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import com.cg.bean.Booking;
import com.cg.bean.HotelDetails;
// to do database operations
public class BookingDAOImpl implements IBookingDAO {
	@PersistenceContext
	EntityManager entityManager= null;
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	@Override
	public List<HotelDetails> displayAllHotels() {
		return entityManager.createQuery("from hoteldetails hotel", HotelDetails.class).getResultList();
	}


}

