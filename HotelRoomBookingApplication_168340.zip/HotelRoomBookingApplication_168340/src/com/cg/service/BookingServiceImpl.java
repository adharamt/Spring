package com.cg.service;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.bean.HotelDetails;
import com.cg.dao.IBookingDAO;
// Business logic
@Service
public class BookingServiceImpl implements IBookingService{

	@Autowired
	IBookingDAO hotelDao=null;

	public IBookingDAO getHotelDao() {
		return hotelDao;
	}

	public void setHotelDao(IBookingDAO hotelDao) {
		this.hotelDao = hotelDao;
	}
	@Override
	public List<HotelDetails> displayAllHotels() {
		return hotelDao.displayAllHotels();
	}
}





