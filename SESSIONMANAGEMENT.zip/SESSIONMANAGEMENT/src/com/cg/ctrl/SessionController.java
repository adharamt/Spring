package com.cg.ctrl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.Session1;
import com.cg.service.ISessionService;


@Controller
public class SessionController {
	@Autowired
	ISessionService iSessionService;


	public ISessionService getiSessionService() {
		return iSessionService;
	}




	public void setiSessionService(ISessionService iSessionService) {
		this.iSessionService = iSessionService;
	}




	@RequestMapping(value="/listSession", method=RequestMethod.GET)
	public String displaySessionDetails(Model model) {
		ArrayList<Session1>userList=(ArrayList<Session1>) iSessionService.displayAllSessions();
		model.addAttribute("userListObj",userList);
		return"ListAllSession";
	}




	@RequestMapping(value="/Sucess", method=RequestMethod.GET)
	public String displaySucess(@RequestParam(value="reg")String sName
			,Model model) {
		ArrayList<Session1>userList=(ArrayList<Session1>) iSessionService.displayAllSessions();
		model.addAttribute("hotel_name",sName);
		return"Sucess";
	}
}
