package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class QueryDAOImpl implements QueryDAO{
	@PersistenceContext
	EntityManager entityManager= null;
	QueryMaster queryMaster;
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	@Override
	public QueryMaster getQueryDetails(int query_Id) {
		
		return entityManager.find(QueryMaster.class,query_Id );
	}
	@Override
	public QueryMaster updateUsers(QueryMaster queryMaster) {
	entityManager.find(QueryMaster.class, queryMaster.getQuery_Id());
	QueryMaster re= entityManager.merge(queryMaster);
	entityManager.flush();
	return re;
	}
}
