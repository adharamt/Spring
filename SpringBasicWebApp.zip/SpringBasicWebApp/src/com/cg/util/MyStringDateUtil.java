package com.cg.util;

public class MyStringDateUtil {

	public static String fromArrayToCommaSeparatedString(String strArray[])
	{
		System.out.println("**********From Array String**********");
		StringBuffer str=new StringBuffer();
		for (String tempStr:strArray )
		{
			str.append(tempStr+",");
			//str+=tempStr+",";			
		}
		return str.toString();
	}
}
