package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Trainee;
import com.cg.dao.TraineeDao;
@Service
public class TraineeServiceImpl implements TraineeService{
	@Autowired
TraineeDao traineeDao=null;

	public TraineeDao getTraineeDao() {
	return traineeDao;
}

public void setTraineeDao(TraineeDao traineeDao) {
	this.traineeDao = traineeDao;
}

	@Override
	public Trainee insertUserDetails(Trainee trainee) {
		// TODO Auto-generated method stub
		return traineeDao.insertUserDetails(trainee);
	}

	@Override
	public ArrayList<Trainee> getAllUserDetails() {
		// TODO Auto-generated method stub
		return traineeDao.getAllUserDetails();
	}

	@Override
	public Trainee deleteUsers(int traineeId) {
		// TODO Auto-generated method stub
		return traineeDao.deleteUsers(traineeId);
	}

	@Override
	public Trainee updateUsers(Trainee trainee) {
		// TODO Auto-generated method stub
		return traineeDao.updateUsers(trainee);
	}

	@Override
	public Trainee getTraineeDetails(int traineeId) {
		// TODO Auto-generated method stub
		return traineeDao.getTraineeDetails(traineeId);
	}

}
