package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmpAnnotationDemo {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("cgbeans.xml");
		//Employee Employee=(Employee)ctx.getBean("ankEmp1");
		//System.out.println(e1);
		
		//Employee e2=(Employee)ctx.getBean("e2");
		//System.out.println(e2);
		User u1=(User)ctx.getBean("u1");
		System.out.println(u1);
	}

}
