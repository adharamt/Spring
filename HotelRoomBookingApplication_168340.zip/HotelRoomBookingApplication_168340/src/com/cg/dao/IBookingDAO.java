package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Booking;
import com.cg.bean.HotelDetails;

public interface IBookingDAO {
	public List<HotelDetails> displayAllHotels();
	

}
