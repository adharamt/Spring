package com.cg.service;

import com.cg.bean.QueryMaster;

public interface QuaryService {
	public QueryMaster getQuerryDetails(int query_Id);
	public QueryMaster updateUsers(QueryMaster queryMaster);
}
