
	package com.cg.bean;

import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("e2")//for property file {"${eid}"}
	public class Employee {
	@Value("168340")
		private int employeeId;
	@Value("Ankita")
		private String employeeName;
	@Value("45812")
		private float salary;
	@Resource(name="getAddList")
	private ArrayList<Address>empAdd;
		public Employee() {
			super();
			// TODO Auto-generated constructor stub
		}
		public int getEmployeeId() {
			return employeeId;
		}
		public void setEmployeeId(int employeeId) {
			this.employeeId = employeeId;
		}
		public String getEmployeeName() {
			return employeeName;
		}
		public void setEmployeeName(String employeeName) {
			this.employeeName = employeeName;
		}
		public float getSalary() {
			return salary;
		}
		public void setSalary(float salary) {
			this.salary = salary;
		}
		@Override
		public String toString() {
			return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary=" + salary + "]";
		}
		
	}


