package com.cg.ctrl;

import javax.management.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.bean.QueryMaster;
import com.cg.service.QuaryService;


@Controller
public class QueryController {
	@Autowired
	QuaryService quaryService=null;

	public QuaryService getQuaryService() {
		return quaryService;
	}

	public void setQuaryService(QuaryService quaryService) {
		this.quaryService = quaryService;
	}

	@RequestMapping(value="/displayQuery",method=RequestMethod.GET)
	public String displayQuery(Model model) {
		model.addAttribute("query", new QueryMaster());
		return "Query";
	}

	@RequestMapping(value="/findQuery",method=RequestMethod.POST)
	public String updateUser(@ModelAttribute(value="query") QueryMaster queryMaster,Model model) {

		QueryMaster rd=quaryService.getQuerryDetails(queryMaster.getQuery_Id()); 
		model.addAttribute("qry", rd);
		return  "QueryUpdate";

	}
	@RequestMapping(value="/updateUserDetails",method=RequestMethod.POST)
	public String updateUserDetails(@ModelAttribute(value="qry") QueryMaster queryMaster,Model model) {

		QueryMaster rd=quaryService.updateUsers(queryMaster);
		model.addAttribute("msg", "Updated Successfully");
		return  "QuerySucess";




	}
}
