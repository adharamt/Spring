package com.cg.payroll.daoservices;import java.util.ArrayList;
import java.util.HashMap;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.cg.payroll.beans.Associate;

public class AssociateDAOImpl implements AssociateDAO{
	private EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");

	@Override
	public Associate save(Associate associate) {
		return associate;
		
	}

	@Override
	public boolean update(Associate associate) {
	
		return true;
	}

	@Override
	public Associate findOne(int associateID) {
		return entityManagerFactory.createEntityManager().find(Associate.class, associateID);
	}

	@Override
	public java.util.List<Associate> findAll() {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Query query=entityManager.createQuery("from Associate a");
		return query.getResultList();
	}
}
