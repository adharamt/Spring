package com.cg.service;

import com.cg.bean.Product;

public interface QuaryService {
	public Product getQuerryDetails(int query_Id);
	public Product updateUsers(Product product);
	public Product getProductDetails(int productId);
}
