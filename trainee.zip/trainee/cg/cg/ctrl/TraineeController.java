package com.cg.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.Login;
import com.cg.bean.Trainee;

import com.cg.service.TraineeService;
@Controller
public class TraineeController {
	@Autowired
	TraineeService traineeService=null;

	public TraineeService getTraineeService() {
		return traineeService;
	}

	public void setTraineeService(TraineeService traineeService) {
		this.traineeService = traineeService;
	}
	@RequestMapping(value="/ShowLoginPage",method=RequestMethod.GET)
	public String displayLoginPage(Model model) { //return type is string it return only viewname
		Login lg=new Login();

		model.addAttribute("log",lg);         //add the data in the model
		return "Login";
	}
	@RequestMapping(value="/ValidateUser", method=RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value="log")
	@Valid Login lg,BindingResult result,Model model) {
		if(lg.getUsername().equalsIgnoreCase("admin")&&lg.getPassword().equalsIgnoreCase("admin"))
		{
			return "Menu";
		}else	
			return "error";//retrive data form login page when we will go we use model

	}




	@RequestMapping(value="/ShowRegisterPage")
	public String dispRegPage(Model model) {

		Trainee rd=new Trainee();
		model.addAttribute("reg",rd);

		return "addEmployee";

	}
	@RequestMapping(value="/InsertUser",method=RequestMethod.POST)
	public String addUserDetails(@ModelAttribute(value="reg")
	@Valid
	Trainee rd,BindingResult result,Model model) {
		Trainee rdd=traineeService.insertUserDetails(rd);

		return "Success";

	}
	@RequestMapping(value="/listUser",method=RequestMethod.GET)
	public String listAllUsers(@ModelAttribute(value="reg")
	@Valid
	Trainee rd,BindingResult result,Model model) {

		ArrayList<Trainee>userList=traineeService.getAllUserDetails();//retrive data from array list
		model.addAttribute("userListObj",userList);
		return "ListAllUser";

	}
	@RequestMapping(value="/deleteTrainee",method=RequestMethod.GET)
	public String DisplayDeleteTrainee(Model model) {
		model.addAttribute("trainee", new Trainee());
		return "abc";
	}
	@RequestMapping(value="/deleteUser",method=RequestMethod.POST)
	public String deleteUser(@ModelAttribute(value="trainee") Trainee trainee,Model model) {
		Trainee rd=traineeService.deleteUsers(trainee.getTraineeId());
		if(rd!=null) {
			ArrayList<Trainee>userList=traineeService.getAllUserDetails();
			model.addAttribute("userListObj", userList);
			model.addAttribute("MsgObj","data deleted");
			return "ListAllUser";
		}
		else {
			return "Error";
		}
	}


	@RequestMapping(value="/displayTrainee",method=RequestMethod.GET)
	public String DisplayTrainee(Model model) {
		model.addAttribute("trainee", new Trainee());
		return "displayTrainee";
	}
	@RequestMapping(value="/displayUser",method=RequestMethod.POST)
	public String displayUser(@ModelAttribute(value="trainee") Trainee trainee,Model model) {
		Trainee rd=traineeService.getTraineeDetails(trainee.getTraineeId());		
		model.addAttribute("msg", rd);
		return  "displayTrainee";

	}
	/*********updateUser****************/
	@RequestMapping(value="/updateUser",method=RequestMethod.GET)
	public String DisplayUpdateTrainee(Model model) {
		model.addAttribute("trainee", new Trainee());

		return "Update";
	}

	@RequestMapping(value="/updateUserDetails",method=RequestMethod.POST)
	public String updateUser(@ModelAttribute(value="trainee") Trainee trainee,Model model) {
		Trainee rd=traineeService.updateUsers(trainee);
		model.addAttribute("msg", rd);
		return  "displayUser";

	}

}
