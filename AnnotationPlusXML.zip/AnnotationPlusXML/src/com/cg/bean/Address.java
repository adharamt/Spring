package com.cg.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("offAdd")
public class Address {
    @Value("MH")
    private String state;
    @Value("Shirpur")
    private String city;
    @Value("425405")
    private long zipcode;
    public Address() {
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public long getZipcode() {
        return zipcode;
    }
    public void setZipcode(long zipcode) {
        this.zipcode = zipcode;
    }
    
    @Override
    public String toString() {
        return "Address [state=" + state + ", city=" + city + ", zipcode=" + zipcode + "]";
    }

}

