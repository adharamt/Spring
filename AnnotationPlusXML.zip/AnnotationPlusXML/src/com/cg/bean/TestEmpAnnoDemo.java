package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmpAnnoDemo {

    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("cgbeans.xml");
        Employee emp1=(Employee) ctx.getBean("Nikiemp1");
        System.out.println("******empInfo****");
       System.out.println(emp1);
       System.out.println("******EmpBean********");
      Emp e2=(Emp) ctx.getBean("e2");
      System.out.println(e2);
      System.out.println("******UserBean********");
      User u1=(User) ctx.getBean("u1");
      System.out.println(u1);
    }

}
