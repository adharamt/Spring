package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Login;
import com.cg.bean.Trainee;
import com.cg.dao.TraineeDao;
@Service("traiSer")
public class TraineeServiceImpl implements TraineeService{
	@Autowired
	TraineeDao traDao=null;
	

	public TraineeDao getTraDao() {
		return traDao;
	}

	public void setTraDao(TraineeDao traDao) {
		this.traDao = traDao;
	}

	@Override
	public Login validateUser(Login login) {
Login dbUser=traDao.validateUser(login);
		
		if(login.getUsername().equalsIgnoreCase("Priya123")&&login.getPassword().equalsIgnoreCase("Priya123")) {

			return login ;
		}
		else
		{
			return null;
		}

	
	}

	@Override
	public Trainee insertUserDetails(Trainee trainee) {
		System.out.println("TraineeDetails");
		
		return traDao.insertUserDetails(trainee);
	}

	@Override
	public ArrayList<Trainee> getAllUserDetails() {
	
		return traDao.getAllUserDetails();
	}

	@Override
	public Trainee deteteUsers(int traineeId) {
		return traDao.deteteUsers(traineeId);
	}
	@Override
	public Trainee getTraineeDetails(int traineeId) {
	
		return traDao.getTraineeDetails(traineeId);
	}

	@Override
	public Trainee updateUsers(Trainee trainee) {
	
		return traDao.updateUsers(trainee);
	}

}
