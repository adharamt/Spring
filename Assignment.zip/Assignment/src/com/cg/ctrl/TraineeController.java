package com.cg.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.bean.Login;
import com.cg.bean.Trainee;
import com.cg.service.TraineeService;

@Controller
public class TraineeController {
	@Autowired
	TraineeService traiSer;

	ArrayList<String> domainList=null;



	public ArrayList<String> getDomainList() {
		return domainList;
	}

	public void setDomainList(ArrayList<String> domainList) {
		this.domainList = domainList;
	}



	public TraineeService getTraiSer() {
		return traiSer;
	}

	public void setTraiSer(TraineeService traiSer) {
		this.traiSer = traiSer;
	}

	@RequestMapping(value="/ShowLoginPage",method=RequestMethod.GET)
	public String displayLoginPage(Model model) {

		Login lg=new Login();
		model.addAttribute("log", lg);
		model.addAttribute("compNameObj","Capgemini");
		return "Login";
	}
	@RequestMapping(value="/ValidateUser",method=RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value="log")  @Valid Trainee lg,BindingResult result, Model model) {
		if(result.hasErrors()) { 
			return "Login";
		}
		else {
			return "TraineeManagementSystem";
		}
	}

	/*---------------------------------------Show Register--------------*/

	@RequestMapping(value="/EnterTraineeDetails")
	public String dispRegPage(Model model)
	{
		domainList=new ArrayList<>();
		domainList.add("Java");
		domainList.add("DotNet");
		domainList.add("Oracle");
		Trainee td=new Trainee();
		model.addAttribute("reg",td);
		model.addAttribute("dList",domainList);

		return "EnterTraineeDetails";
	}

	/*-------------------------------------------Insert Details----------------------------*/
	@RequestMapping(value="/InsertUser",method=RequestMethod.POST)
	public String addUserDetails(@ModelAttribute(value="reg") Trainee reg,Model model) {
		if(traiSer.insertUserDetails(reg)!= null)
			return "Success";
		return "Failure";


	}
	/*-------------------------------------------DeleteUser Details----------------------------*/
    @RequestMapping(value="/deleteUser",method=RequestMethod.POST)  //first
    public String deleteUser( Trainee trainee,Model model) {
        Trainee rd=traiSer.deteteUsers(trainee.getTraineeId());
        if(rd!=null) {
            ArrayList<Trainee>userList=traiSer.getAllUserDetails();
            model.addAttribute("userListObj", userList);
            model.addAttribute("MsgObj", "data deleted");
            return "ListAllUser";
        }
        return "Failure";
    
}
    @RequestMapping(value="/listUser",method=RequestMethod.GET)
    public String listAllUsers(@ModelAttribute(value="reg")
    @Valid
    Trainee rd,BindingResult result,Model model) {

        ArrayList<Trainee>userList=traiSer.getAllUserDetails();//retrive data from array list
        model.addAttribute("userListObj",userList);
        return "ListAllUser";

    }
    @RequestMapping(value="/updateUser",method=RequestMethod.GET)
    public String DisplayUpdateTrainee(Model model) {
        model.addAttribute("trainee", new Trainee());

        return "UpdatePage";
    }

    @RequestMapping(value="/findUserDetails",method=RequestMethod.POST)
    public String updateUser(@ModelAttribute(value="trainee") Trainee trainee,Model model) {
        
        Trainee rd=traiSer.getTraineeDetails(trainee.getTraineeId());        
        return  "UpdatePage";

    }
    @RequestMapping(value="/updateUserDetails",method=RequestMethod.POST)
    public String updateUserDetails(@ModelAttribute(value="trainee") Trainee trainee,Model model) {
        
        Trainee rd=traiSer.updateUsers(trainee);
        model.addAttribute("msg", "Updated Successfully");
        return  "UpdatePage";




}
}