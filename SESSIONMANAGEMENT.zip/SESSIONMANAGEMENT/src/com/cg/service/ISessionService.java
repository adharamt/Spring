package com.cg.service;

import java.util.List;

import com.cg.bean.Session1;

public interface ISessionService {
	 public List<Session1>displayAllSessions();
}
