package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Session1;
import com.cg.dao.ISessionDAO;
@Service
public class SessionServiceImpl implements ISessionService{
	@Autowired
	ISessionDAO sessionDao=null;
	
	public ISessionDAO getSessionDao() {
		return sessionDao;
	}



	public void setSessionDao(ISessionDAO sessionDao) {
		this.sessionDao = sessionDao;
	}


	



@Override
public List<Session1> displayAllSessions() {
	
	return sessionDao.displayAllSessions();
}
}
