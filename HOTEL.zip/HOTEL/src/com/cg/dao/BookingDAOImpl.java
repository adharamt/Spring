package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.HotelDetails;
// to do database operations
@Repository
@Transactional
public class BookingDAOImpl implements IBookingDAO {
	@PersistenceContext
	EntityManager entityManager= null;
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	@Override
	public List<HotelDetails> displayAllHotels() {
		return entityManager.createQuery("from HotelDetails h", HotelDetails.class).getResultList();
	}


}

