package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.Login;
import com.cg.bean.Trainee;

public interface TraineeDao {
	public Login validateUser(Login login);
	public Trainee  insertUserDetails(Trainee trainee);
	public ArrayList<Trainee>getAllUserDetails();
	public Trainee deteteUsers(int traineeId);
	public Trainee getTraineeDetails(int traineeId);

}
