package com.cg.dao;

import com.cg.bean.QueryMaster;

public interface QueryDAO {
	public QueryMaster getQueryDetails(int query_Id);
	public QueryMaster updateUsers(QueryMaster queryMaster);
}
