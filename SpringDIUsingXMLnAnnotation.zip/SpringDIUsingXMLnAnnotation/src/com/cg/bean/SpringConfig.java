package com.cg.bean;

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {
	@Bean
public ArrayList<Address>getAddList()
{
	Address ad1=new Address();
	ad1.setCity("Mumbai");
	ad1.setState("mah");
	ad1.setZipcode(1245);
	
	Address ad2=new Address();
	ad2.setCity("Mumbai");
	ad2.setState("mah");
	ad2.setZipcode(1245);
	
	ArrayList<Address>addList=new ArrayList<Address>();
	addList.add(ad1);
	addList.add(ad2);
	ArrayList<Address>adlist=new ArrayList<Address>();
	return adlist;
}


//-------------------------------------------------
@Bean
public Address getAddress()
{
	Address ad=new Address();
	ad.setCity("chennai");
	ad.setState("tamilnadu");
	ad.setZipcode(1554);
	return ad;
}}