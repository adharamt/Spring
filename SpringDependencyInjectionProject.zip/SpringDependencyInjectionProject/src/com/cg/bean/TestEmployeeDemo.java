package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployeeDemo {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("cgbeans.xml");
/*Employee emp1=(Employee)ctx.getBean("ankobj");
System.out.println("----Emp Info------");
System.out.println("Id- "+emp1.getEmpId()+
		" First Name- "+emp1.getEmpName()+
		"Salary- "+emp1.getEmpSal()+
		"Address- "+emp1.getAddress().getState()+", "
		+emp1.getAddress().getCity()+", "+emp1.getAddress().getZipcode());*/

System.out.println("---------------");	
Emp emp2=(Emp)ctx.getBean("lalitobj");
System.out.println("----Emp Info------");
System.out.println("Id-  "+emp2.getEmpId()+
		" First Name-  "+emp2.getEmpName()+
		"Salary-  "+emp2.getEmpSal()+
		"Address-  "+emp2.getEmpadd());
	}

}
