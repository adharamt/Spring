package com.cg.payroll.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Associate {
	@Id
	private int associateID;
	private int yearlyInvestmentUnder80C;
	private String fisrtName, lastName, department, designation, pancard, emaiID;
	public Associate() {
		super();
	}
	public Associate(int associateID, int yearlyInvestmentUnder80C, String fisrtName, String lastName,
			String department, String designation, String pancard, String emaiID) {
		super();
		this.associateID = associateID;
		this.yearlyInvestmentUnder80C = yearlyInvestmentUnder80C;
		this.fisrtName = fisrtName;
		this.lastName = lastName;
		this.department = department;
		this.designation = designation;
		this.pancard = pancard;
		this.emaiID = emaiID;
	}
	public int getAssociateID() {
		return associateID;
	}
	public void setAssociateID(int associateID) {
		this.associateID = associateID;
	}
	public int getYearlyInvestmentUnder80C() {
		return yearlyInvestmentUnder80C;
	}
	public void setYearlyInvestmentUnder80C(int yearlyInvestmentUnder80C) {
		this.yearlyInvestmentUnder80C = yearlyInvestmentUnder80C;
	}
	public String getFisrtName() {
		return fisrtName;
	}
	public void setFisrtName(String fisrtName) {
		this.fisrtName = fisrtName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public String getEmaiID() {
		return emaiID;
	}
	public void setEmaiID(String emaiID) {
		this.emaiID = emaiID;
	}
	@Override
	public String toString() {
		return "Associate [associateID=" + associateID + ", yearlyInvestmentUnder80C=" + yearlyInvestmentUnder80C
				+ ", fisrtName=" + fisrtName + ", lastName=" + lastName + ", department=" + department
				+ ", designation=" + designation + ", pancard=" + pancard + ", emaiID=" + emaiID + "]";
	}
}






