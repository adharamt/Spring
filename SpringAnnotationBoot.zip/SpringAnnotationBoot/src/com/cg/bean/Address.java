package com.cg.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("ankoffAdd")
public class Address {
	@Value("Maharashtra")
private String state;
	@Value("Pune")
private String city;
	@Value("4512")
private int zipcode;
public Address() {
	super();
	// TODO Auto-generated constructor stub
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public long getZipcode() {
	return zipcode;
}
public void setZipcode(int zipcode) {
	this.zipcode = zipcode;
}
@Override
public String toString() {
	return "Address [state=" + state + ", city=" + city + ", zipcode=" + zipcode + "]";
}

}
