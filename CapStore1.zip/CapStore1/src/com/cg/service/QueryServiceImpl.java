package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.QueryMaster;
import com.cg.dao.QueryDAO;

@Service
public class QueryServiceImpl implements QuaryService{
@Autowired
QueryDAO queryDAO=null;

public QueryDAO getQueryDAO() {
	return queryDAO;
}

public void setQueryDAO(QueryDAO queryDAO) {
	this.queryDAO = queryDAO;
}
@Override
public QueryMaster getQuerryDetails(int productid) {
	return queryDAO.getQueryDetails(productid);
}

@Override
public QueryMaster updateUsers(QueryMaster queryMaster) {
	
	return queryDAO.updateUsers(queryMaster);
}
}
