package com.cg.staticdb;

import java.util.ArrayList;

import com.cg.bean.Country;

public class CountryDb {
private static ArrayList<Country>countryList=new ArrayList<Country>();
static
{
	countryList.add(new Country("1001","India","2145414"));
	countryList.add(new Country("1002","US","48571"));
	countryList.add(new Country("1003","UK","897545"));
	countryList.add(new Country("1004","Pak","325648"));
	countryList.add(new Country("1005","Austrlia","1487956"));
}
public static ArrayList<Country> getCountryList() {
	return countryList;
}
public static void setCountryList(ArrayList<Country> countryList) {
	CountryDb.countryList = countryList;
}


}
