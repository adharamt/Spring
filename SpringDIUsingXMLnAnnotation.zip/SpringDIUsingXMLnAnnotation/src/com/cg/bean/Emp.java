package com.cg.bean;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component("ankEmp1")
public class Emp {
	@Value("168340")
	private int empId;
	@Value("Ankita Dharamthok")
	private String empName;
	@Value("50000")
	private float empSal;
	@Autowired
	@Qualifier("getAddress")//auto wiring by name
private Address empadd;
	public Emp() {
		super();
		
	}
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}

	public Address getEmpadd() {
		return empadd;
	}

	public void setEmpadd(Address empadd) {
		this.empadd = empadd;
	}

	@Override
	public String toString() {
		return "Emp [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", empadd=" + empadd + "]";
	}

	
}
