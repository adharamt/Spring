package com.cg.bean;

import javax.persistence.Entity;

@Entity
public class OrderDetails {
private int	orderId;
private int userId , couponId, cartItemId, date;
private String address, status;
public OrderDetails() {
	super();
}
public OrderDetails(int orderId, int userId, int couponId, int cartItemId, int date, String address, String status) {
	super();
	this.orderId = orderId;
	this.userId = userId;
	this.couponId = couponId;
	this.cartItemId = cartItemId;
	this.date = date;
	this.address = address;
	this.status = status;
}
public int getOrderId() {
	return orderId;
}                                 
public void setOrderId(int orderId) {
	this.orderId = orderId;
}
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
public int getCouponId() {
	return couponId;
}
public void setCouponId(int couponId) {
	this.couponId = couponId;
}
public int getCartItemId() {
	return cartItemId;
}
public void setCartItemId(int cartItemId) {
	this.cartItemId = cartItemId;
}
public int getDate() {
	return date;
}
public void setDate(int date) {
	this.date = date;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}

}
