package com.cg.bean;

public class Booking {
public int id;

public Booking() {
	super();
	
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}


}
